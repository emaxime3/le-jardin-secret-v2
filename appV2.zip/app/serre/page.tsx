export default function Serre() {
  return <h1>La Serre</h1>;
}