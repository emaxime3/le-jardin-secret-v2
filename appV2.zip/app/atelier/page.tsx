export default function Atelier() {
  return <h1>L'Atelier</h1>;
}