"use client";

type BookProps = {
  title: string;
  content: string;
  onClose: () => void;
};

export default function Book({
  title,
  content,
  onClose,
}: BookProps) {
  return (
    <div className="book-overlay" onClick={onClose}>

      <div
        className="book"
        onClick={(e) => e.stopPropagation()}
      >

        <button
          className="book-close"
          onClick={onClose}
        >
          ✕
        </button>

        <h2>{title}</h2>

        <div className="book-content">

          {content}

        </div>

      </div>

    </div>
  );
}