"use client";

import { useState } from "react";
import Book from "./Book";

type CarnetProps = {
  titre: string;
  description: string;
};

export default function Carnet({
  titre,
  description,
}: CarnetProps) {
  const [ouvert, setOuvert] = useState(false);

  return (
    <>
      <div
        className="carnet-card"
        onClick={() => setOuvert(true)}
      >
        <div className="carnet-icon">
          📖
        </div>

        <h2>{titre}</h2>

        <p className="carnet-text">
          {description}
        </p>

        <span className="open-carnet">
          Ouvrir le carnet →
        </span>
      </div>

      {ouvert && (
        <Book
          title="L'Âme"
          content={`Ici apparaîtra ton premier poème...

Nous remplacerons bientôt ce texte par ton vrai poème.`}
          onClose={() => setOuvert(false)}
        />
      )}
    </>
  );
}