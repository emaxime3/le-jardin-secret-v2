import Carnet from "../components/carnet";

export default function Banc() {
  return (

<main className="banc">

      {/* HERO */}

      <section className="banc-hero">

        <img
          src="/images/banc.jpg"
          alt="Le Banc"
        />

        <div className="banc-overlay">

          <p className="banc-type">
            Les poèmes
          </p>

          <h1>Le Banc</h1>

          <p className="banc-intro">
            Sous un vieil olivier face à la mer,
            les mots prennent le temps de respirer.
          </p>

        </div>

      </section>

      {/* LE CARNET */}

 <section className="carnet-section">

  <Carnet
    titre="Le Carnet"
    description="Quelques pages ont résisté au temps. Elles n'attendent plus qu'un lecteur."
  />

</section>

    </main>
  );
}