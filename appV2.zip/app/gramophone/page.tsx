export default function Gramophone() {
  return <h1>Le Gramophone</h1>;
}