import Link from "next/link";

export default function Home() {
  return (
    <>
      <div className="background"></div>

      <div className="overlay"></div>

      <main className="hero">

        <div className="book">

          <h1>Le Jardin Secret</h1>

          <p className="subtitle">
            Là où les mots prennent racine.
          </p>

          <p className="quote">
            Ici, chaque poème est une promenade,
            chaque chanson une saison,
            chaque silence une fleur qui attend d'éclore.
          </p>

         <Link href="/sentier">
  <button>
  Entrer →
  </button>
</Link>
        </div>

      </main>

    </>
  );
}
<div className="card-text">

  <h3>Le Gramophone</h3>

  <p>Là où les chansons prennent vie.</p>

  <span className="mini-link">
    Découvrir →
  </span>

</div>