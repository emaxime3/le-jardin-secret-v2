export default function Belvedere() {
  return <h1>Le Belvédère</h1>;
}