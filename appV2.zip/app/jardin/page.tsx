import Link from "next/link";

export default function Jardin() {
  return (
    <main className="garden">

      <header className="garden-header">

        <h1>Le Jardin Secret</h1>

        <p>
          Chaque lieu possède une histoire.
          Prenez le temps de choisir où vous souhaitez commencer votre promenade.
        </p>

      </header>

      {/* INTRODUCTION AU JARDIN */}

      <section className="featured-place">

        <div className="featured-card">

          <img
            src="/images/hero.jpg"
            alt="Le Jardin Secret"
          />

          <div className="featured-content">

            <p className="place-type">
              Bienvenue
            </p>

            <h2>Le Jardin Secret</h2>

            <p className="place-description">
              Chaque sentier mène à une histoire.
              Choisissez le lieu où vous souhaitez commencer votre promenade.
            </p>

            <div className="line"></div>

          </div>

        </div>

      </section>

      <div className="chapter-title">

        <span>Choisissez un lieu pour commencer votre promenade</span>

      </div>

      <section className="places-grid">

        {/* LE BANC */}

        <Link href="/banc" className="place-card">

          <img
            src="/images/banc.jpg"
            alt="Le Banc"
          />

          <div className="card-text">

            <p>Les poèmes</p>

            <h3>Le Banc</h3>

            <span className="mini-link">
              Découvrir →
            </span>

          </div>

        </Link>

        {/* LE GRAMOPHONE */}

        <Link href="/gramophone" className="place-card">

          <img
            src="/images/gramophone.png"
            alt="Le Gramophone"
          />

          <div className="card-text">

            <p>Là où les chansons prennent vie.</p>

            <h3>Le Gramophone</h3>

            <span className="mini-link">
              Découvrir →
            </span>

          </div>

        </Link>

        {/* L'ATELIER */}

        <Link href="/atelier" className="place-card">

          <img
            src="/images/atelier.png"
            alt="L'Atelier"
          />

          <div className="card-text">

            <p>Carnets, esquisses et pensées.</p>

            <h3>L'Atelier</h3>

            <span className="mini-link">
              Découvrir →
            </span>

          </div>

        </Link>

        {/* LA SERRE */}

        <Link href="/serre" className="place-card">

          <img
            src="/images/serre.png"
            alt="La Serre"
          />

          <div className="card-text">

            <p>Les projets qui grandissent en silence.</p>

            <h3>La Serre</h3>

            <span className="mini-link">
              Découvrir →
            </span>

          </div>

        </Link>

        {/* LE BELVÉDÈRE */}

        <Link href="/belvedere" className="place-card">

          <img
            src="/images/belvedere.png"
            alt="Le Belvédère"
          />

          <div className="card-text">

            <p>Là où l'on contemple le chemin parcouru.</p>

            <h3>Le Belvédère</h3>

            <span className="mini-link">
              Découvrir →
            </span>

          </div>

        </Link>

      </section>

      <footer className="garden-quote">

        <p>
          « Certains jardins fleurissent avec des fleurs.
          Celui-ci fleurit avec des mots. »
        </p>

      </footer>

    </main>
  );
}